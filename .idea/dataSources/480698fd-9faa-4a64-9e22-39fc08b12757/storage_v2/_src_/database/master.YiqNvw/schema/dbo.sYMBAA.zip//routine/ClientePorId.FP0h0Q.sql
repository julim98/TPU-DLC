CREATE PROCEDURE [dbo].[ClientePorId]
	
	(
	@IdCliente int
	)
	
AS

select * from clientes where IdCliente = @IdCliente  
	
	RETURN
go

