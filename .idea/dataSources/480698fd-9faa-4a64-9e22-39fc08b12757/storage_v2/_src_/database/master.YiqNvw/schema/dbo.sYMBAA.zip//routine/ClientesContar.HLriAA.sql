CREATE PROCEDURE [dbo].[ClientesContar]
	
	(
	
	@CantidadDeClientes int = 0 OUTPUT 
	)
	
AS
	select @CantidadDeClientes = count(*) from clientes
	RETURN
go

